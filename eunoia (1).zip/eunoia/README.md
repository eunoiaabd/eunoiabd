# EUNOIA — Wear your own universe

Static site, split into clean HTML / CSS / JS. No build step, no framework — just upload and go.

```
eunoia/
├── index.html          ← markup only
├── css/style.css       ← all styles (responsive + reduced-motion)
├── js/main.js          ← slider, product modal, WhatsApp order links, reviews
├── assets/             ← product photos, moon, social + payment icons
├── .nojekyll           ← tells GitHub Pages to serve files as-is
└── README.md
```

---

## 1. Publish on GitHub Pages (5 minutes)

1. Create a new **public** repo on GitHub, e.g. `eunoia`.
2. Upload **everything inside this folder** (index.html, css/, js/, assets/, .nojekyll) to the repo root.
   - Easiest: unzip `eunoia.zip`, drag the contents into the GitHub upload page, commit.
   - Or with Git:
     ```bash
     cd eunoia
     git init
     git add .
     git commit -m "EUNOIA store"
     git branch -M main
     git remote add origin https://github.com/USERNAME/eunoia.git
     git push -u origin main
     ```
3. Repo → **Settings → Pages** → Source: **Deploy from a branch** → Branch: **main** / **/(root)** → Save.
4. Wait ~1 minute. Your site is live at:

   **https://USERNAME.github.io/eunoia/**

> Custom domain later? Settings → Pages → Custom domain (e.g. `eunoia.com`), then add the CNAME record GitHub shows you.

## 2. After you publish — 2 find-and-replace edits

In `index.html` replace the placeholder `USERNAME` in these three lines:

- `<meta property="og:url" content="https://USERNAME.github.io/eunoia/">`
- `<link rel="canonical" href="https://USERNAME.github.io/eunoia/">`
- the `og:image` / `twitter:image` tags can stay relative, or make them absolute:
  `https://USERNAME.github.io/eunoia/assets/tshirt.jpg` (absolute URLs preview better on Facebook/WhatsApp).

## 3. Marketing details already wired in

| What | Where |
|---|---|
| WhatsApp orders | `https://wa.me/8801708331114` + modal order button (two numbers) |
| Facebook | facebook.com/share/1CEXaVhsyC |
| Instagram | @eunoia69x |
| Payments | bKash & Nagad — 01708331114 |
| Social share preview | Open Graph + Twitter meta tags in `<head>` |

Change prices, product names or images in the `products` array at the top of `js/main.js`.

## 4. Notes

- Product photos are AI-generated placeholders — swap the files in `assets/` (keep the same filenames) with your real shots.
- Reviews are saved in the visitor's own browser (localStorage), not shared between visitors. For public reviews you'd need a backend (e.g. Supabase / Firebase).
- The Google Fonts `Inter` is loaded from CDN, so the in-app preview may fall back to Arial; on the live GitHub Pages site it loads normally.
- Contact form: there is none — ordering is WhatsApp-only by design, which is also the fastest path for a small Bangladeshi store.
