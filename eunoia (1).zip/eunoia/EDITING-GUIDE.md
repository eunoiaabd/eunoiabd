# EUNOIA — Editing cheat sheet

Everything you'll normally change, and exactly which file/line to touch.
No build tools, no framework. Save the file → refresh the browser → done.

---

## 1. The 90% of edits

| You want to change… | Open this file | Find |
|---|---|---|
| Product name / price | `js/main.js` | `const products = [` (top of file) |
| Product photo | `assets/` | replace the file, keep the same filename |
| WhatsApp numbers | `index.html` | search `8801708331114` |
| Instagram / Facebook links | `index.html` | search `instagram.com` / `facebook.com` |
| School of colors (yellow, sage) | `css/style.css` | `#ffd600` (yellow), `#708d88` (sage), `#efefed` (page bg) |
| Headline text ("GOOD STYLE") | `index.html` | search `hero-title` |
| Contact section copy | `index.html` | search `FAVORITE WEAR` |
| Payment numbers | `index.html` | search `bKash` |

### Example — change a price
`js/main.js` line 10-ish:

```js
{ name: "Full Sleeve Shirt", img: "assets/longshirt.jpg", price: "৳ 1,850" },
```
→ just edit the price string. Keep the `"` quotes and the trailing comma.

### Example — add a 6th product
Copy one line, paste it above `];`, change the three values:

```js
{ name: "Oversized Tee", img: "assets/oversized.jpg", price: "৳ 1,150" }
```
Then put the photo at `assets/oversized.jpg`. The slider picks it up automatically — nothing else to edit.

### Example — change the brand color
`css/style.css`: replace every `#ffd600` with your hex code (e.g. `#ff5a1f`).
Find-and-replace all, there are ~3 spots.

---

## 2. How to edit the files

Pick whichever is comfortable:

- **Directly on GitHub (no install, works on phone):** open the file in your repo → pencil icon → edit → *Commit changes*. Site updates in ~1 minute.
- **Locally on your computer:** install [VS Code](https://code.visualstudio.com), open the `eunoia` folder, edit, save.
- **Ask me here:** tell me what to change, I'll edit the files in this workspace and re-zip. Then you re-upload to GitHub.

## 3. How the change goes live

**If you edited on GitHub:** nothing else to do. GitHub Pages rebuilds automatically in about 30–60 seconds. If you see the old version, hard-refresh: `Ctrl+Shift+R` (Windows) / `Cmd+Shift+R` (Mac) — the old CSS is often just cached.

**If you edited locally:** you must push the change.

Either upload the changed files through the GitHub web UI, or with Git:

```bash
cd eunoia
git add .
git commit -m "update prices"
git push
```

**If a layout breaks after an edit:** 99% of the time it's a missing `"` quote, a missing `,` between products, or a missing `}` in CSS. Open the browser console (`F12` → Console) — it tells you the line number.

---

## 4. Photos: the one rule

The code points at **exact filenames**. To swap a photo you either

- keep the same name (`assets/tshirt.jpg`) and overwrite the file, or
- use a new name and update the path in `js/main.js` (`img: "assets/my-new-photo.jpg"`).

Keep photos **square, 800×800px, under ~150 KB** (export as JPG quality 80) so the site stays fast on mobile data. Filenames: lowercase, no spaces — `full-sleeve-shirt.jpg`, not `Full Sleeve Shirt.JPG`.

---

## 5. Good next steps (when you're ready)

- **Custom domain** — buy `eunoia.com` (or `.store`/`.shop`), then GitHub repo → Settings → Pages → Custom domain. Marketing link becomes `eunoia.com`. Needs a DNS `CNAME` record pointing to `YOUR-USERNAME.github.io`.
- **Real product pages / more photos per item** — currently one photo per product in a modal. Tell me and I'll add a photo gallery per product.
- **Public reviews** — right now reviews save only in each visitor's own browser. For reviews everyone can see, you need a small backend (Supabase free tier works well). Ask me and I'll wire it up.
- **Order tracking / cart** — the site is WhatsApp-order-only by design, which is usually right for a small BD store.
- **SEO basics** — after publishing, submit the URL to [Google Search Console](https://search.google.com/search-console) so you show up when people search "EUNOIA".

---

## 6. Backups (do this once)

Because `index.html`, `css/style.css` and `js/main.js` are plain text, one wrong edit is easy to undo — but only if you have a copy:

- Keep `eunoia.zip` somewhere safe (Google Drive).
- Git users: GitHub keeps every commit. Bad edit on GitHub? Click the file → *History* → revert.

---

### Quick reference — file map

```
index.html      text and structure (what's on the page)
css/style.css   look: colors, spacing, fonts, mobile rules
js/main.js      behaviour: products, prices, slider, modal, WhatsApp links
assets/         images (jpg photos + png icons)
```
